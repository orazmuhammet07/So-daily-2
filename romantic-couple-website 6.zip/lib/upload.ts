import { createClient } from "@/lib/supabase/client"

export async function uploadPhoto(file: File): Promise<string> {
  const supabase = createClient()

  // Generate unique filename
  const fileExt = file.name.split(".").pop()
  const fileName = `${Math.random().toString(36).substring(2)}-${Date.now()}.${fileExt}`
  const filePath = `${fileName}`

  // Upload file to Supabase Storage
  const { error: uploadError } = await supabase.storage.from("photos").upload(filePath, file, {
    cacheControl: "3600",
    upsert: false,
  })

  if (uploadError) {
    throw new Error(`Upload failed: ${uploadError.message}`)
  }

  // Get public URL
  const { data } = supabase.storage.from("photos").getPublicUrl(filePath)

  return data.publicUrl
}

export async function deletePhotoFromStorage(url: string): Promise<void> {
  const supabase = createClient()

  // Extract filename from URL
  const fileName = url.split("/").pop()
  if (!fileName) return

  await supabase.storage.from("photos").remove([fileName])
}
