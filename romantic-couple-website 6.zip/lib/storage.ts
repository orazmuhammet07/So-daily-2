// Storage utilities for localStorage management

export interface Memory {
  id: string
  text: string
  author: "Oraz" | "Soyli"
  date: string
  photos?: string[]
  voiceNote?: string
}

export interface MoodEntry {
  id: string
  date: string
  mood: "harika" | "mutlu" | "normal" | "üzgün" | "kötü"
  author: "Oraz" | "Soyli"
  note?: string
}

export interface Photo {
  id: string
  url: string
  caption?: string
  date: string
  author: "Oraz" | "Soyli"
}

export interface Song {
  id: string
  title: string
  artist: string
  url?: string
  addedBy: "Oraz" | "Soyli"
  date: string
  note?: string
}

export interface SurpriseMessage {
  id: string
  message: string
  from: "Oraz" | "Soyli"
  to: "Oraz" | "Soyli"
  date: string
  opened: boolean
  openDate?: string
}

export interface Dream {
  id: string
  title: string
  description: string
  date: string
  completed: boolean
  author: "Oraz" | "Soyli"
}

// Storage keys
const STORAGE_KEYS = {
  MEMORIES: "orazsoyli_memories",
  MOODS: "orazsoyli_moods",
  PHOTOS: "orazsoyli_photos",
  SONGS: "orazsoyli_songs",
  SURPRISES: "orazsoyli_surprises",
  DREAMS: "orazsoyli_dreams",
}

// Generic storage functions
export function getFromStorage<T>(key: string): T[] {
  if (typeof window === "undefined") return []
  const data = localStorage.getItem(key)
  return data ? JSON.parse(data) : []
}

export function saveToStorage<T>(key: string, data: T[]): void {
  if (typeof window === "undefined") return
  localStorage.setItem(key, JSON.stringify(data))
}

// Memory functions
export function getMemories(): Memory[] {
  return getFromStorage<Memory>(STORAGE_KEYS.MEMORIES)
}

export function saveMemory(memory: Omit<Memory, "id">): Memory {
  const memories = getMemories()
  const newMemory: Memory = {
    ...memory,
    id: Date.now().toString(),
  }
  memories.unshift(newMemory)
  saveToStorage(STORAGE_KEYS.MEMORIES, memories)
  return newMemory
}

export function deleteMemory(id: string): void {
  const memories = getMemories().filter((m) => m.id !== id)
  saveToStorage(STORAGE_KEYS.MEMORIES, memories)
}

// Mood functions
export function getMoods(): MoodEntry[] {
  return getFromStorage<MoodEntry>(STORAGE_KEYS.MOODS)
}

export function saveMood(mood: Omit<MoodEntry, "id">): MoodEntry {
  const moods = getMoods()
  const newMood: MoodEntry = {
    ...mood,
    id: Date.now().toString(),
  }
  moods.unshift(newMood)
  saveToStorage(STORAGE_KEYS.MOODS, moods)
  return newMood
}

// Photo functions
export function getPhotos(): Photo[] {
  return getFromStorage<Photo>(STORAGE_KEYS.PHOTOS)
}

export function savePhoto(photo: Omit<Photo, "id">): Photo {
  const photos = getPhotos()
  const newPhoto: Photo = {
    ...photo,
    id: Date.now().toString(),
  }
  photos.unshift(newPhoto)
  saveToStorage(STORAGE_KEYS.PHOTOS, photos)
  return newPhoto
}

export function deletePhoto(id: string): void {
  const photos = getPhotos().filter((p) => p.id !== id)
  saveToStorage(STORAGE_KEYS.PHOTOS, photos)
}

// Song functions
export function getSongs(): Song[] {
  return getFromStorage<Song>(STORAGE_KEYS.SONGS)
}

export function saveSong(song: Omit<Song, "id">): Song {
  const songs = getSongs()
  const newSong: Song = {
    ...song,
    id: Date.now().toString(),
  }
  songs.unshift(newSong)
  saveToStorage(STORAGE_KEYS.SONGS, songs)
  return newSong
}

export function deleteSong(id: string): void {
  const songs = getSongs().filter((s) => s.id !== id)
  saveToStorage(STORAGE_KEYS.SONGS, songs)
}

// Surprise functions
export function getSurprises(): SurpriseMessage[] {
  return getFromStorage<SurpriseMessage>(STORAGE_KEYS.SURPRISES)
}

export function saveSurprise(surprise: Omit<SurpriseMessage, "id">): SurpriseMessage {
  const surprises = getSurprises()
  const newSurprise: SurpriseMessage = {
    ...surprise,
    id: Date.now().toString(),
  }
  surprises.unshift(newSurprise)
  saveToStorage(STORAGE_KEYS.SURPRISES, surprises)
  return newSurprise
}

export function openSurprise(id: string): void {
  const surprises = getSurprises()
  const updated = surprises.map((s) => (s.id === id ? { ...s, opened: true, openDate: new Date().toISOString() } : s))
  saveToStorage(STORAGE_KEYS.SURPRISES, updated)
}

// Dream functions
export function getDreams(): Dream[] {
  return getFromStorage<Dream>(STORAGE_KEYS.DREAMS)
}

export function saveDream(dream: Omit<Dream, "id">): Dream {
  const dreams = getDreams()
  const newDream: Dream = {
    ...dream,
    id: Date.now().toString(),
  }
  dreams.unshift(newDream)
  saveToStorage(STORAGE_KEYS.DREAMS, dreams)
  return newDream
}

export function toggleDreamComplete(id: string): void {
  const dreams = getDreams()
  const updated = dreams.map((d) => (d.id === id ? { ...d, completed: !d.completed } : d))
  saveToStorage(STORAGE_KEYS.DREAMS, updated)
}

export function deleteDream(id: string): void {
  const dreams = getDreams().filter((d) => d.id !== id)
  saveToStorage(STORAGE_KEYS.DREAMS, dreams)
}
