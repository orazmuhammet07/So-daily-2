"use client"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { createClient } from "@/lib/supabase/client"
import { format, subDays, startOfDay } from "date-fns"
import { tr } from "date-fns/locale"
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { TrendingUp } from "lucide-react"

const moodLabels = {
  5: "Harika",
  4: "Mutlu",
  3: "Normal",
  2: "Üzgün",
  1: "Kötü",
}

type MoodEntry = {
  id: string
  author: string
  mood: number
  date: string
  created_at: string
}

export function MoodGraph() {
  const [moods, setMoods] = useState<MoodEntry[]>([])
  const [days, setDays] = useState<number>(7)

  useEffect(() => {
    loadMoods()
  }, [])

  const loadMoods = async () => {
    const supabase = createClient()
    const { data, error } = await supabase.from("moods").select("*").order("date", { ascending: false })

    if (!error && data) {
      setMoods(data)
    }
  }

  const chartData = useMemo(() => {
    const data = []
    const today = startOfDay(new Date())

    for (let i = days - 1; i >= 0; i--) {
      const date = subDays(today, i)
      const dateStr = format(date, "yyyy-MM-dd")
      const dayMoods = moods.filter((mood) => mood.date === dateStr)

      const orazMood = dayMoods.find((m) => m.author === "Oraz")
      const soyliMood = dayMoods.find((m) => m.author === "Soyli")

      data.push({
        date: format(date, "d MMM", { locale: tr }),
        Oraz: orazMood ? orazMood.mood : null,
        Soyli: soyliMood ? soyliMood.mood : null,
      })
    }

    return data
  }, [moods, days])

  const averageMood = useMemo(() => {
    if (moods.length === 0) return null

    const recentMoods = moods.slice(0, days)
    const orazMoods = recentMoods.filter((m) => m.author === "Oraz")
    const soyliMoods = recentMoods.filter((m) => m.author === "Soyli")

    const orazAvg = orazMoods.length > 0 ? orazMoods.reduce((sum, m) => sum + m.mood, 0) / orazMoods.length : 0

    const soyliAvg = soyliMoods.length > 0 ? soyliMoods.reduce((sum, m) => sum + m.mood, 0) / soyliMoods.length : 0

    return {
      oraz: orazAvg.toFixed(1),
      soyli: soyliAvg.toFixed(1),
      overall: ((orazAvg + soyliAvg) / 2).toFixed(1),
    }
  }, [moods, days])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-primary">Ruh Hali Grafiği</h2>
          <p className="text-muted-foreground mt-1">Zaman içindeki ruh hali değişimleri</p>
        </div>
        <Select value={days.toString()} onValueChange={(value) => setDays(Number(value))}>
          <SelectTrigger className="w-32">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">7 Gün</SelectItem>
            <SelectItem value="14">14 Gün</SelectItem>
            <SelectItem value="30">30 Gün</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {averageMood && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Oraz Ortalama</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                <span className="text-2xl font-bold">{averageMood.oraz}</span>
                <span className="text-sm text-muted-foreground">/ 5</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Soyli Ortalama</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-accent" />
                <span className="text-2xl font-bold">{averageMood.soyli}</span>
                <span className="text-sm text-muted-foreground">/ 5</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Genel Ortalama</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                <span className="text-2xl font-bold">{averageMood.overall}</span>
                <span className="text-sm text-muted-foreground">/ 5</span>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Ruh Hali Trendi</CardTitle>
        </CardHeader>
        <CardContent>
          {moods.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12">
              <TrendingUp className="w-16 h-16 text-muted-foreground mb-4" />
              <p className="text-lg font-medium mb-2">Henüz veri yok</p>
              <p className="text-sm text-muted-foreground text-center">
                Ruh hali kayıtları ekledikçe grafik burada görünecek
              </p>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis
                  domain={[1, 5]}
                  ticks={[1, 2, 3, 4, 5]}
                  tickFormatter={(value) => moodLabels[value as keyof typeof moodLabels]}
                  className="text-xs"
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "var(--radius)",
                  }}
                  formatter={(value: number) => [moodLabels[value as keyof typeof moodLabels], ""]}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="Oraz"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--primary))", r: 4 }}
                  connectNulls
                />
                <Line
                  type="monotone"
                  dataKey="Soyli"
                  stroke="hsl(var(--accent))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--accent))", r: 4 }}
                  connectNulls
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
