"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Trash2, Sparkles, CheckCircle2, Circle } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { format } from "date-fns"
import { tr } from "date-fns/locale"

type Dream = {
  id: string
  dream: string
  author: string
  completed: boolean
  created_at: string
}

export function FutureDreams() {
  const [dreams, setDreams] = useState<Dream[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newDream, setNewDream] = useState({
    dream: "",
    author: "Oraz" as "Oraz" | "Soyli",
  })

  useEffect(() => {
    loadDreams()
  }, [])

  const loadDreams = async () => {
    const supabase = createClient()
    const { data, error } = await supabase.from("dreams").select("*").order("created_at", { ascending: false })

    if (!error && data) {
      setDreams(data)
    }
  }

  const handleAddDream = async () => {
    if (!newDream.dream.trim()) return

    try {
      const supabase = createClient()
      const { data, error } = await supabase
        .from("dreams")
        .insert({
          dream: newDream.dream,
          author: newDream.author,
          completed: false,
        })
        .select()
        .single()

      if (error) throw error

      setDreams([data, ...dreams])
      setNewDream({ dream: "", author: "Oraz" })
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Error adding dream:", error)
      alert("Hayal eklenirken bir hata oluştu")
    }
  }

  const handleToggleComplete = async (id: string, currentStatus: boolean) => {
    try {
      const supabase = createClient()
      const { error } = await supabase.from("dreams").update({ completed: !currentStatus }).eq("id", id)

      if (error) throw error

      setDreams(dreams.map((d) => (d.id === id ? { ...d, completed: !d.completed } : d)))
    } catch (error) {
      console.error("Error toggling dream:", error)
      alert("Hayal güncellenirken bir hata oluştu")
    }
  }

  const handleDeleteDream = async (id: string) => {
    try {
      const supabase = createClient()
      const { error } = await supabase.from("dreams").delete().eq("id", id)

      if (error) throw error

      setDreams(dreams.filter((d) => d.id !== id))
    } catch (error) {
      console.error("Error deleting dream:", error)
      alert("Hayal silinirken bir hata oluştu")
    }
  }

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "d MMMM yyyy", { locale: tr })
    } catch {
      return dateString
    }
  }

  const activeDreams = dreams.filter((d) => !d.completed)
  const completedDreams = dreams.filter((d) => d.completed)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-primary">Gelecek Hayallerimiz</h2>
          <p className="text-muted-foreground mt-1">Birlikte gerçekleştirmek istediğimiz hayaller</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="gap-2">
              <Plus className="w-5 h-5" />
              Hayal Ekle
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Yeni Hayal Ekle</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Kim ekliyor?</Label>
                <Select
                  value={newDream.author}
                  onValueChange={(value: "Oraz" | "Soyli") => setNewDream({ ...newDream, author: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Oraz">Oraz</SelectItem>
                    <SelectItem value="Soyli">Soyli</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Hayal</Label>
                <Textarea
                  placeholder="Örn: Paris'e seyahat etmek, birlikte bir ev almak..."
                  value={newDream.dream}
                  onChange={(e) => setNewDream({ ...newDream, dream: e.target.value })}
                  rows={5}
                  className="resize-none"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                İptal
              </Button>
              <Button onClick={handleAddDream} disabled={!newDream.dream.trim()}>
                Ekle
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {dreams.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-3">
              <p className="text-sm font-medium text-muted-foreground">Toplam Hayal</p>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold">{dreams.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <p className="text-sm font-medium text-muted-foreground">Devam Eden</p>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-primary">{activeDreams.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-3">
              <p className="text-sm font-medium text-muted-foreground">Gerçekleşen</p>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-accent">{completedDreams.length}</p>
            </CardContent>
          </Card>
        </div>
      )}

      {activeDreams.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <h3 className="text-xl font-semibold">Hayallerimiz</h3>
          </div>
          <div className="space-y-3">
            {activeDreams.map((dream) => (
              <Card key={dream.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <button
                      onClick={() => handleToggleComplete(dream.id, dream.completed)}
                      className="flex-shrink-0 mt-1 hover:scale-110 transition-transform"
                    >
                      <Circle className="w-6 h-6 text-primary" />
                    </button>
                    <div className="flex-1 min-w-0">
                      <p className="text-foreground leading-relaxed mb-2">{dream.dream}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{dream.author} tarafından eklendi</span>
                        <span>•</span>
                        <span>{formatDate(dream.created_at)}</span>
                      </div>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="text-destructive hover:text-destructive flex-shrink-0"
                      onClick={() => handleDeleteDream(dream.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {completedDreams.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-accent" />
            <h3 className="text-xl font-semibold">Gerçekleşen Hayaller</h3>
          </div>
          <div className="space-y-3">
            {completedDreams.map((dream) => (
              <Card key={dream.id} className="bg-accent/5 border-accent/20 hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <button
                      onClick={() => handleToggleComplete(dream.id, dream.completed)}
                      className="flex-shrink-0 mt-1 hover:scale-110 transition-transform"
                    >
                      <CheckCircle2 className="w-6 h-6 text-accent fill-accent" />
                    </button>
                    <div className="flex-1 min-w-0">
                      <p className="text-foreground leading-relaxed mb-2 line-through decoration-accent/50">
                        {dream.dream}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{dream.author} tarafından eklendi</span>
                        <span>•</span>
                        <span>{formatDate(dream.created_at)}</span>
                      </div>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="text-destructive hover:text-destructive flex-shrink-0"
                      onClick={() => handleDeleteDream(dream.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {dreams.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Sparkles className="w-16 h-16 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">Henüz hayal eklenmemiş</p>
            <p className="text-sm text-muted-foreground text-center mb-4">
              Birlikte gerçekleştirmek istediğiniz hayalleri ekleyin
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
