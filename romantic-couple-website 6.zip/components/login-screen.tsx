"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Heart } from "lucide-react"

interface LoginScreenProps {
  onLogin: (password: string) => boolean
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [password, setPassword] = useState("")
  const [error, setError] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const success = onLogin(password)
    if (!success) {
      setError(true)
      setPassword("")
      setTimeout(() => setError(false), 2000)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-accent/10 p-4">
      <Card className="w-full max-w-md shadow-xl border-primary/20">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="relative">
              <Heart className="w-16 h-16 text-primary fill-primary animate-pulse" />
              <Heart className="w-8 h-8 text-accent fill-accent absolute -bottom-2 -right-2" />
            </div>
          </div>
          <CardTitle className="text-3xl font-bold text-primary">Oraz & Soyli</CardTitle>
          <CardDescription className="text-base">Bizim özel dünyamıza hoş geldiniz</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Input
                type="password"
                placeholder="Şifre"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`text-center text-lg ${error ? "border-destructive" : ""}`}
                autoFocus
              />
              {error && (
                <p className="text-sm text-destructive text-center animate-shake">Yanlış şifre, tekrar deneyin</p>
              )}
            </div>
            <Button type="submit" className="w-full text-lg" size="lg">
              Giriş Yap
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
