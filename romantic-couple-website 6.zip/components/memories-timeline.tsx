"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Trash2, Calendar, User, Upload } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { uploadPhoto, deletePhotoFromStorage } from "@/lib/upload"
import { format } from "date-fns"
import { tr } from "date-fns/locale"

type Memory = {
  id: string
  text: string
  author: string
  photo_url?: string
  created_at: string
}

export function MemoriesTimeline() {
  const [memories, setMemories] = useState<Memory[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [newMemory, setNewMemory] = useState({
    text: "",
    author: "Oraz" as "Oraz" | "Soyli",
    photoFile: null as File | null,
  })

  useEffect(() => {
    loadMemories()
  }, [])

  const loadMemories = async () => {
    const supabase = createClient()
    const { data, error } = await supabase.from("memories").select("*").order("created_at", { ascending: false })

    if (!error && data) {
      setMemories(data)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setNewMemory({ ...newMemory, photoFile: file })
    }
  }

  const handleAddMemory = async () => {
    if (!newMemory.text.trim()) return

    setIsUploading(true)
    try {
      let photoUrl: string | undefined

      // Upload photo if selected
      if (newMemory.photoFile) {
        photoUrl = await uploadPhoto(newMemory.photoFile)
      }

      // Save to database
      const supabase = createClient()
      const { data, error } = await supabase
        .from("memories")
        .insert({
          content: newMemory.text,
          author: newMemory.author,
          photo_url: photoUrl || null,
        })
        .select()
        .single()

      if (error) throw error

      setMemories([data, ...memories])
      setNewMemory({ text: "", author: "Oraz", photoFile: null })
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Error adding memory:", error)
      alert("Anı eklenirken bir hata oluştu")
    } finally {
      setIsUploading(false)
    }
  }

  const handleDeleteMemory = async (memory: Memory) => {
    try {
      const supabase = createClient()

      // Delete from database
      const { error } = await supabase.from("memories").delete().eq("id", memory.id)

      if (error) throw error

      // Delete photo from storage if exists
      if (memory.photo_url) {
        await deletePhotoFromStorage(memory.photo_url)
      }

      setMemories(memories.filter((m) => m.id !== memory.id))
    } catch (error) {
      console.error("Error deleting memory:", error)
      alert("Anı silinirken bir hata oluştu")
    }
  }

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "d MMMM yyyy, HH:mm", { locale: tr })
    } catch {
      return dateString
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-primary">Anılarımız</h2>
          <p className="text-muted-foreground mt-1">Birlikte yaşadığımız özel anlar</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="gap-2">
              <Plus className="w-5 h-5" />
              Yeni Anı
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Yeni Anı Ekle</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Kim yazıyor?</Label>
                <Select
                  value={newMemory.author}
                  onValueChange={(value: "Oraz" | "Soyli") => setNewMemory({ ...newMemory, author: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Oraz">Oraz</SelectItem>
                    <SelectItem value="Soyli">Soyli</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Anı</Label>
                <Textarea
                  placeholder="Bugün birlikte ne yaptık? Ne hissettik?"
                  value={newMemory.text}
                  onChange={(e) => setNewMemory({ ...newMemory, text: e.target.value })}
                  rows={6}
                  className="resize-none"
                />
              </div>

              <div className="space-y-2">
                <Label>Fotoğraf Ekle (İsteğe bağlı)</Label>
                <div className="flex items-center gap-2">
                  <Input type="file" accept="image/*" onChange={handleFileChange} className="cursor-pointer" />
                  <Upload className="w-5 h-5 text-muted-foreground" />
                </div>
                {newMemory.photoFile && (
                  <div className="mt-2">
                    <img
                      src={URL.createObjectURL(newMemory.photoFile) || "/placeholder.svg"}
                      alt="Önizleme"
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  </div>
                )}
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)} disabled={isUploading}>
                İptal
              </Button>
              <Button onClick={handleAddMemory} disabled={!newMemory.text.trim() || isUploading}>
                {isUploading ? "Kaydediliyor..." : "Kaydet"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {memories.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Calendar className="w-16 h-16 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">Henüz anı eklenmemiş</p>
            <p className="text-sm text-muted-foreground text-center mb-4">İlk anınızı ekleyerek başlayın</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {memories.map((memory) => (
            <Card key={memory.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center ${memory.author === "Oraz" ? "bg-primary/10" : "bg-accent/10"}`}
                    >
                      <User className={`w-5 h-5 ${memory.author === "Oraz" ? "text-primary" : "text-accent"}`} />
                    </div>
                    <div>
                      <p className="font-semibold">{memory.author}</p>
                      <p className="text-xs text-muted-foreground">{formatDate(memory.created_at)}</p>
                    </div>
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="text-destructive hover:text-destructive"
                    onClick={() => handleDeleteMemory(memory)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-foreground leading-relaxed whitespace-pre-wrap">{memory.content}</p>
                {memory.photo_url && (
                  <img
                    src={memory.photo_url || "/placeholder.svg"}
                    alt="Anı fotoğrafı"
                    className="w-full h-64 object-cover rounded-lg"
                  />
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
