"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Gift, Lock, Unlock, Sparkles } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { format } from "date-fns"
import { tr } from "date-fns/locale"

type SurpriseMessage = {
  id: string
  message: string
  author: string
  opened: boolean
  opened_at?: string
  created_at: string
}

export function SurpriseBox() {
  const [surprises, setSurprises] = useState<SurpriseMessage[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedSurprise, setSelectedSurprise] = useState<SurpriseMessage | null>(null)
  const [newSurprise, setNewSurprise] = useState({
    message: "",
    author: "Oraz" as "Oraz" | "Soyli",
  })

  useEffect(() => {
    loadSurprises()
  }, [])

  const loadSurprises = async () => {
    const supabase = createClient()
    const { data, error } = await supabase.from("surprises").select("*").order("created_at", { ascending: false })

    if (!error && data) {
      setSurprises(data)
    }
  }

  const handleAddSurprise = async () => {
    if (!newSurprise.message.trim()) return

    try {
      const supabase = createClient()
      const { data, error } = await supabase
        .from("surprises")
        .insert({
          message: newSurprise.message,
          author: newSurprise.author,
          opened: false,
        })
        .select()
        .single()

      if (error) throw error

      setSurprises([data, ...surprises])
      setNewSurprise({ message: "", author: "Oraz" })
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Error adding surprise:", error)
      alert("Sürpriz eklenirken bir hata oluştu")
    }
  }

  const handleOpenSurprise = async (surprise: SurpriseMessage) => {
    if (!surprise.opened) {
      try {
        const supabase = createClient()
        const { error } = await supabase
          .from("surprises")
          .update({ opened: true, opened_at: new Date().toISOString() })
          .eq("id", surprise.id)

        if (error) throw error

        setSurprises(
          surprises.map((s) =>
            s.id === surprise.id ? { ...s, opened: true, opened_at: new Date().toISOString() } : s,
          ),
        )
      } catch (error) {
        console.error("Error opening surprise:", error)
      }
    }
    setSelectedSurprise(surprise)
  }

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "d MMMM yyyy, HH:mm", { locale: tr })
    } catch {
      return dateString
    }
  }

  const unopenedSurprises = surprises.filter((s) => !s.opened)
  const openedSurprises = surprises.filter((s) => s.opened)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-primary">Sürpriz Kutusu</h2>
          <p className="text-muted-foreground mt-1">Birbirinize gizli mesajlar bırakın</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="gap-2">
              <Plus className="w-5 h-5" />
              Sürpriz Ekle
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Yeni Sürpriz Mesaj</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Kimden?</Label>
                <Select
                  value={newSurprise.author}
                  onValueChange={(value: "Oraz" | "Soyli") => setNewSurprise({ ...newSurprise, author: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Oraz">Oraz</SelectItem>
                    <SelectItem value="Soyli">Soyli</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Sürpriz Mesaj</Label>
                <Textarea
                  placeholder="Sevgilinize özel bir mesaj yazın..."
                  value={newSurprise.message}
                  onChange={(e) => setNewSurprise({ ...newSurprise, message: e.target.value })}
                  rows={6}
                  className="resize-none"
                />
              </div>

              <div className="bg-accent/10 p-3 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  Bu mesaj {newSurprise.author === "Oraz" ? "Soyli" : "Oraz"} tarafından açılana kadar gizli kalacak
                </p>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                İptal
              </Button>
              <Button onClick={handleAddSurprise} disabled={!newSurprise.message.trim()}>
                Gönder
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Unopened Surprises */}
      {unopenedSurprises.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-primary" />
            <h3 className="text-xl font-semibold">Açılmamış Sürprizler ({unopenedSurprises.length})</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {unopenedSurprises.map((surprise) => (
              <Card
                key={surprise.id}
                className="cursor-pointer hover:shadow-lg transition-all hover:scale-105 bg-gradient-to-br from-primary/10 to-accent/10 border-primary/20"
                onClick={() => handleOpenSurprise(surprise)}
              >
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <div className="relative mb-4">
                    <Gift className="w-16 h-16 text-primary animate-pulse" />
                    <Sparkles className="w-6 h-6 text-accent absolute -top-2 -right-2" />
                  </div>
                  <p className="font-semibold text-lg mb-1">Sana bir sürpriz!</p>
                  <p className="text-sm text-muted-foreground mb-3">{surprise.author} sana bir mesaj bıraktı</p>
                  <Button size="sm" className="gap-2">
                    <Unlock className="w-4 h-4" />
                    Aç ve Oku
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Opened Surprises */}
      {openedSurprises.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Unlock className="w-5 h-5 text-muted-foreground" />
            <h3 className="text-xl font-semibold">Açılmış Sürprizler</h3>
          </div>
          <div className="space-y-3">
            {openedSurprises.map((surprise) => (
              <Card
                key={surprise.id}
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setSelectedSurprise(surprise)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Gift className="w-5 h-5 text-muted-foreground" />
                      <div>
                        <p className="font-semibold">{surprise.author}</p>
                        <p className="text-xs text-muted-foreground">{formatDate(surprise.created_at)}</p>
                      </div>
                    </div>
                    <Unlock className="w-4 h-4 text-muted-foreground" />
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-foreground line-clamp-2">{surprise.message}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {surprises.length === 0 && (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Gift className="w-16 h-16 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">Henüz sürpriz yok</p>
            <p className="text-sm text-muted-foreground text-center mb-4">Sevgilinize özel bir sürpriz mesaj bırakın</p>
          </CardContent>
        </Card>
      )}

      {/* Surprise Detail Dialog */}
      <Dialog open={!!selectedSurprise} onOpenChange={() => setSelectedSurprise(null)}>
        <DialogContent className="max-w-2xl">
          {selectedSurprise && (
            <div className="space-y-4">
              <div className="flex items-center justify-center">
                <div className="relative">
                  <Gift className="w-20 h-20 text-primary" />
                  {!selectedSurprise.opened && <Sparkles className="w-8 h-8 text-accent absolute -top-2 -right-2" />}
                </div>
              </div>
              <div className="text-center">
                <p className="text-sm text-muted-foreground mb-1">{selectedSurprise.author}</p>
                <p className="text-xs text-muted-foreground">{formatDate(selectedSurprise.created_at)}</p>
              </div>
              <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
                <CardContent className="p-6">
                  <p className="text-foreground leading-relaxed whitespace-pre-wrap text-center text-lg">
                    {selectedSurprise.message}
                  </p>
                </CardContent>
              </Card>
              {selectedSurprise.opened_at && (
                <p className="text-xs text-center text-muted-foreground">
                  Açılma tarihi: {formatDate(selectedSurprise.opened_at)}
                </p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
