"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Trash2, ImageIcon, Upload } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { uploadPhoto, deletePhotoFromStorage } from "@/lib/upload"
import { format } from "date-fns"
import { tr } from "date-fns/locale"

type Photo = {
  id: string
  url: string
  caption?: string
  author: string
  created_at: string
}

export function PhotoAlbum() {
  const [photos, setPhotos] = useState<Photo[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [newPhoto, setNewPhoto] = useState({
    file: null as File | null,
    caption: "",
    author: "Oraz" as "Oraz" | "Soyli",
  })

  useEffect(() => {
    loadPhotos()
  }, [])

  const loadPhotos = async () => {
    const supabase = createClient()
    const { data, error } = await supabase.from("photos").select("*").order("created_at", { ascending: false })

    if (!error && data) {
      setPhotos(data)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setNewPhoto({ ...newPhoto, file })
    }
  }

  const handleAddPhoto = async () => {
    if (!newPhoto.file) return

    setIsUploading(true)
    try {
      // Upload file to storage
      const url = await uploadPhoto(newPhoto.file)

      // Save to database
      const supabase = createClient()
      const { data, error } = await supabase
        .from("photos")
        .insert({
          url,
          caption: newPhoto.caption || null,
          author: newPhoto.author,
        })
        .select()
        .single()

      if (error) throw error

      setPhotos([data, ...photos])
      setNewPhoto({ file: null, caption: "", author: "Oraz" })
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Error adding photo:", error)
      alert("Fotoğraf yüklenirken bir hata oluştu")
    } finally {
      setIsUploading(false)
    }
  }

  const handleDeletePhoto = async (photo: Photo) => {
    try {
      const supabase = createClient()

      // Delete from database
      const { error } = await supabase.from("photos").delete().eq("id", photo.id)

      if (error) throw error

      // Delete from storage
      await deletePhotoFromStorage(photo.url)

      setPhotos(photos.filter((p) => p.id !== photo.id))
      setSelectedPhoto(null)
    } catch (error) {
      console.error("Error deleting photo:", error)
      alert("Fotoğraf silinirken bir hata oluştu")
    }
  }

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "d MMMM yyyy", { locale: tr })
    } catch {
      return dateString
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-primary">Fotoğraf Albümü</h2>
          <p className="text-muted-foreground mt-1">Birlikte çektiğimiz özel anlar</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="gap-2">
              <Plus className="w-5 h-5" />
              Fotoğraf Ekle
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Yeni Fotoğraf Ekle</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Kim ekliyor?</Label>
                <Select
                  value={newPhoto.author}
                  onValueChange={(value: "Oraz" | "Soyli") => setNewPhoto({ ...newPhoto, author: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Oraz">Oraz</SelectItem>
                    <SelectItem value="Soyli">Soyli</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Fotoğraf Seç</Label>
                <div className="flex items-center gap-2">
                  <Input type="file" accept="image/*" onChange={handleFileChange} className="cursor-pointer" />
                  <Upload className="w-5 h-5 text-muted-foreground" />
                </div>
                {newPhoto.file && <p className="text-sm text-muted-foreground">Seçilen: {newPhoto.file.name}</p>}
              </div>

              {newPhoto.file && (
                <div className="space-y-2">
                  <Label>Önizleme</Label>
                  <img
                    src={URL.createObjectURL(newPhoto.file) || "/placeholder.svg"}
                    alt="Önizleme"
                    className="w-full h-48 object-cover rounded-lg"
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label>Açıklama (İsteğe bağlı)</Label>
                <Textarea
                  placeholder="Bu fotoğraf hakkında bir şeyler yaz..."
                  value={newPhoto.caption}
                  onChange={(e) => setNewPhoto({ ...newPhoto, caption: e.target.value })}
                  rows={3}
                  className="resize-none"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)} disabled={isUploading}>
                İptal
              </Button>
              <Button onClick={handleAddPhoto} disabled={!newPhoto.file || isUploading}>
                {isUploading ? "Yükleniyor..." : "Ekle"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {photos.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <ImageIcon className="w-16 h-16 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">Henüz fotoğraf eklenmemiş</p>
            <p className="text-sm text-muted-foreground text-center mb-4">İlk fotoğrafınızı ekleyerek başlayın</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {photos.map((photo) => (
            <Card
              key={photo.id}
              className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow group"
              onClick={() => setSelectedPhoto(photo)}
            >
              <div className="relative aspect-square">
                <img
                  src={photo.url || "/placeholder.svg"}
                  alt={photo.caption || "Fotoğraf"}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <p className="text-white text-sm font-medium px-2 text-center line-clamp-2">
                    {photo.caption || "Fotoğrafa tıklayın"}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Photo Detail Dialog */}
      <Dialog open={!!selectedPhoto} onOpenChange={() => setSelectedPhoto(null)}>
        <DialogContent className="max-w-3xl">
          {selectedPhoto && (
            <div className="space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-lg">{selectedPhoto.author}</p>
                  <p className="text-sm text-muted-foreground">{formatDate(selectedPhoto.created_at)}</p>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="text-destructive hover:text-destructive"
                  onClick={() => handleDeletePhoto(selectedPhoto)}
                >
                  <Trash2 className="w-5 h-5" />
                </Button>
              </div>
              <img
                src={selectedPhoto.url || "/placeholder.svg"}
                alt={selectedPhoto.caption || "Fotoğraf"}
                className="w-full max-h-[60vh] object-contain rounded-lg"
              />
              {selectedPhoto.caption && (
                <div className="bg-muted p-4 rounded-lg">
                  <p className="text-foreground leading-relaxed">{selectedPhoto.caption}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
