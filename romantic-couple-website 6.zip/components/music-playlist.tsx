"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Trash2, Music, Play, Heart } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { format } from "date-fns"
import { tr } from "date-fns/locale"

type Song = {
  id: string
  title: string
  artist: string
  link?: string
  note?: string
  author: string
  created_at: string
}

export function MusicPlaylist() {
  const [songs, setSongs] = useState<Song[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newSong, setNewSong] = useState({
    title: "",
    artist: "",
    link: "",
    note: "",
    author: "Oraz" as "Oraz" | "Soyli",
  })

  useEffect(() => {
    loadSongs()
  }, [])

  const loadSongs = async () => {
    const supabase = createClient()
    const { data, error } = await supabase.from("songs").select("*").order("created_at", { ascending: false })

    if (!error && data) {
      setSongs(data)
    }
  }

  const handleAddSong = async () => {
    if (!newSong.title.trim() || !newSong.artist.trim()) return

    try {
      const supabase = createClient()
      const { data, error } = await supabase
        .from("songs")
        .insert({
          title: newSong.title,
          artist: newSong.artist,
          link: newSong.link || null,
          note: newSong.note || null,
          author: newSong.author,
        })
        .select()
        .single()

      if (error) throw error

      setSongs([data, ...songs])
      setNewSong({ title: "", artist: "", link: "", note: "", author: "Oraz" })
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Error adding song:", error)
      alert("Şarkı eklenirken bir hata oluştu")
    }
  }

  const handleDeleteSong = async (id: string) => {
    try {
      const supabase = createClient()
      const { error } = await supabase.from("songs").delete().eq("id", id)

      if (error) throw error

      setSongs(songs.filter((s) => s.id !== id))
    } catch (error) {
      console.error("Error deleting song:", error)
      alert("Şarkı silinirken bir hata oluştu")
    }
  }

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "d MMMM yyyy", { locale: tr })
    } catch {
      return dateString
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-primary">Müzik Listemiz</h2>
          <p className="text-muted-foreground mt-1">Birlikte dinlediğimiz özel şarkılar</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="gap-2">
              <Plus className="w-5 h-5" />
              Şarkı Ekle
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Yeni Şarkı Ekle</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Kim ekliyor?</Label>
                <Select
                  value={newSong.author}
                  onValueChange={(value: "Oraz" | "Soyli") => setNewSong({ ...newSong, author: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Oraz">Oraz</SelectItem>
                    <SelectItem value="Soyli">Soyli</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Şarkı Adı</Label>
                <Input
                  placeholder="Şarkının adı"
                  value={newSong.title}
                  onChange={(e) => setNewSong({ ...newSong, title: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Sanatçı</Label>
                <Input
                  placeholder="Sanatçı adı"
                  value={newSong.artist}
                  onChange={(e) => setNewSong({ ...newSong, artist: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Link (İsteğe bağlı)</Label>
                <Input
                  placeholder="Spotify, YouTube, vb. link"
                  value={newSong.link}
                  onChange={(e) => setNewSong({ ...newSong, link: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Not (İsteğe bağlı)</Label>
                <Textarea
                  placeholder="Bu şarkı neden özel?"
                  value={newSong.note}
                  onChange={(e) => setNewSong({ ...newSong, note: e.target.value })}
                  rows={3}
                  className="resize-none"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                İptal
              </Button>
              <Button onClick={handleAddSong} disabled={!newSong.title.trim() || !newSong.artist.trim()}>
                Ekle
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {songs.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Music className="w-16 h-16 text-muted-foreground mb-4" />
            <p className="text-lg font-medium mb-2">Henüz şarkı eklenmemiş</p>
            <p className="text-sm text-muted-foreground text-center mb-4">İlk şarkınızı ekleyerek başlayın</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {songs.map((song) => (
            <Card key={song.id} className="overflow-hidden hover:shadow-lg transition-shadow group">
              <CardContent className="p-0">
                <div className="flex items-start gap-4 p-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Music className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-lg leading-tight mb-1 truncate">{song.title}</h3>
                        <p className="text-sm text-muted-foreground mb-2">{song.artist}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Heart
                            className={`w-3 h-3 ${song.author === "Oraz" ? "text-primary fill-primary" : "text-accent fill-accent"}`}
                          />
                          <span>{song.author} tarafından eklendi</span>
                          <span>•</span>
                          <span>{formatDate(song.created_at)}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {song.link && (
                          <Button size="icon" variant="ghost" asChild>
                            <a href={song.link} target="_blank" rel="noopener noreferrer">
                              <Play className="w-4 h-4" />
                            </a>
                          </Button>
                        )}
                        <Button
                          size="icon"
                          variant="ghost"
                          className="text-destructive hover:text-destructive"
                          onClick={() => handleDeleteSong(song.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    {song.note && (
                      <div className="mt-3 p-3 bg-muted rounded-lg">
                        <p className="text-sm text-foreground leading-relaxed">{song.note}</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {songs.length > 0 && (
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Music className="w-5 h-5 text-primary" />
              <h3 className="font-semibold">Toplam {songs.length} şarkı</h3>
            </div>
          </CardHeader>
        </Card>
      )}
    </div>
  )
}
