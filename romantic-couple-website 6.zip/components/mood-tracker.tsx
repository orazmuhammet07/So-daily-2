"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Plus, Smile, Meh, Frown, Laugh, Angry } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { format } from "date-fns"
import { tr } from "date-fns/locale"

const moodConfig = {
  1: { label: "Kötü", icon: Angry, color: "text-red-500", bgColor: "bg-red-500/10" },
  2: { label: "Üzgün", icon: Frown, color: "text-orange-500", bgColor: "bg-orange-500/10" },
  3: { label: "Normal", icon: Meh, color: "text-yellow-500", bgColor: "bg-yellow-500/10" },
  4: { label: "Mutlu", icon: Smile, color: "text-blue-500", bgColor: "bg-blue-500/10" },
  5: { label: "Harika", icon: Laugh, color: "text-green-500", bgColor: "bg-green-500/10" },
}

type MoodEntry = {
  id: string
  author: string
  mood: number
  date: string
  created_at: string
}

export function MoodTracker() {
  const [moods, setMoods] = useState<MoodEntry[]>([])
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newMood, setNewMood] = useState({
    mood: 4,
    author: "Oraz" as "Oraz" | "Soyli",
  })

  useEffect(() => {
    loadMoods()
  }, [])

  const loadMoods = async () => {
    const supabase = createClient()
    const { data, error } = await supabase.from("moods").select("*").order("created_at", { ascending: false })

    if (!error && data) {
      setMoods(data)
    }
  }

  const handleAddMood = async () => {
    try {
      const supabase = createClient()
      const today = format(new Date(), "yyyy-MM-dd")

      const { data, error } = await supabase
        .from("moods")
        .upsert(
          {
            author: newMood.author,
            mood: newMood.mood,
            date: today,
          },
          { onConflict: "author,date" },
        )
        .select()
        .single()

      if (error) throw error

      await loadMoods()
      setNewMood({ mood: 4, author: "Oraz" })
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Error adding mood:", error)
      alert("Ruh hali eklenirken bir hata oluştu")
    }
  }

  const getTodayMoods = () => {
    const today = format(new Date(), "yyyy-MM-dd")
    return moods.filter((mood) => mood.date === today)
  }

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "d MMMM yyyy, HH:mm", { locale: tr })
    } catch {
      return dateString
    }
  }

  const todayMoods = getTodayMoods()

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-primary">Ruh Hali Takibi</h2>
          <p className="text-muted-foreground mt-1">Bugün nasıl hissediyorsunuz?</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="gap-2">
              <Plus className="w-5 h-5" />
              Ruh Hali Ekle
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Ruh Halini Kaydet</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Kim?</Label>
                <Select
                  value={newMood.author}
                  onValueChange={(value: "Oraz" | "Soyli") => setNewMood({ ...newMood, author: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Oraz">Oraz</SelectItem>
                    <SelectItem value="Soyli">Soyli</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Ruh Hali</Label>
                <div className="grid grid-cols-5 gap-2">
                  {Object.entries(moodConfig).map(([key, config]) => {
                    const Icon = config.icon
                    const moodValue = Number.parseInt(key)
                    const isSelected = newMood.mood === moodValue
                    return (
                      <button
                        key={key}
                        type="button"
                        onClick={() => setNewMood({ ...newMood, mood: moodValue })}
                        className={`flex flex-col items-center gap-2 p-3 rounded-lg border-2 transition-all ${
                          isSelected
                            ? `${config.bgColor} border-current ${config.color}`
                            : "border-border hover:border-muted-foreground"
                        }`}
                      >
                        <Icon className={`w-8 h-8 ${isSelected ? config.color : "text-muted-foreground"}`} />
                        <span className={`text-xs font-medium ${isSelected ? config.color : "text-muted-foreground"}`}>
                          {config.label}
                        </span>
                      </button>
                    )
                  })}
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                İptal
              </Button>
              <Button onClick={handleAddMood}>Kaydet</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Today's Moods */}
      {todayMoods.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Bugünkü Ruh Halleri</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              {todayMoods.map((mood) => {
                const config = moodConfig[mood.mood as keyof typeof moodConfig]
                const Icon = config.icon
                return (
                  <div key={mood.id} className="flex flex-col items-center gap-2">
                    <div className={`${config.bgColor} p-4 rounded-full`}>
                      <Icon className={`w-8 h-8 ${config.color}`} />
                    </div>
                    <span className="text-sm font-medium">{mood.author}</span>
                    <span className={`text-xs ${config.color}`}>{config.label}</span>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mood History */}
      <div className="space-y-4">
        <h3 className="text-xl font-semibold">Geçmiş Kayıtlar</h3>
        {moods.length === 0 ? (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Smile className="w-16 h-16 text-muted-foreground mb-4" />
              <p className="text-lg font-medium mb-2">Henüz ruh hali kaydı yok</p>
              <p className="text-sm text-muted-foreground text-center mb-4">İlk kaydınızı ekleyerek başlayın</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {moods.map((mood) => {
              const config = moodConfig[mood.mood as keyof typeof moodConfig]
              const Icon = config.icon
              return (
                <Card key={mood.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className={`${config.bgColor} p-3 rounded-full flex-shrink-0`}>
                        <Icon className={`w-6 h-6 ${config.color}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-semibold">{mood.author}</span>
                          <span className={`text-sm font-medium ${config.color}`}>{config.label}</span>
                        </div>
                        <p className="text-xs text-muted-foreground">{formatDate(mood.created_at)}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
