"use client"

import { useState } from "react"
import { AuthProvider, useAuth } from "@/components/auth-provider"
import { LoginScreen } from "@/components/login-screen"
import { Navigation } from "@/components/navigation"
import { MemoriesTimeline } from "@/components/memories-timeline"
import { MoodTracker } from "@/components/mood-tracker"
import { MoodGraph } from "@/components/mood-graph"
import { PhotoAlbum } from "@/components/photo-album"
import { MusicPlaylist } from "@/components/music-playlist"
import { SurpriseBox } from "@/components/surprise-box"
import { FutureDreams } from "@/components/future-dreams"

function AppContent() {
  const { isAuthenticated, login } = useAuth()
  const [activeTab, setActiveTab] = useState("memories")

  if (!isAuthenticated) {
    return <LoginScreen onLogin={login} />
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main Content */}
      <main className="lg:ml-64 pt-20 lg:pt-0 p-4 lg:p-8">
        <div className="max-w-4xl mx-auto">
          {activeTab === "memories" && <MemoriesTimeline />}
          {activeTab === "mood" && <MoodTracker />}
          {activeTab === "graph" && <MoodGraph />}
          {activeTab === "photos" && <PhotoAlbum />}
          {activeTab === "music" && <MusicPlaylist />}
          {activeTab === "surprise" && <SurpriseBox />}
          {activeTab === "dreams" && <FutureDreams />}
        </div>
      </main>
    </div>
  )
}

export default function Page() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  )
}
