-- Create memories table
create table if not exists public.memories (
  id uuid primary key default gen_random_uuid(),
  author text not null,
  content text not null,
  photo_url text,
  created_at timestamp with time zone default now()
);

alter table public.memories enable row level security;

-- Allow anyone to read memories (since it's a shared couple app)
create policy "memories_select_all"
  on public.memories for select
  using (true);

create policy "memories_insert_all"
  on public.memories for insert
  with check (true);

create policy "memories_delete_all"
  on public.memories for delete
  using (true);

-- Create moods table
create table if not exists public.moods (
  id uuid primary key default gen_random_uuid(),
  author text not null,
  mood integer not null check (mood >= 1 and mood <= 5),
  date date not null,
  created_at timestamp with time zone default now(),
  unique(author, date)
);

alter table public.moods enable row level security;

create policy "moods_select_all"
  on public.moods for select
  using (true);

create policy "moods_insert_all"
  on public.moods for insert
  with check (true);

create policy "moods_update_all"
  on public.moods for update
  using (true);

-- Create photos table
create table if not exists public.photos (
  id uuid primary key default gen_random_uuid(),
  author text not null,
  url text not null,
  caption text,
  created_at timestamp with time zone default now()
);

alter table public.photos enable row level security;

create policy "photos_select_all"
  on public.photos for select
  using (true);

create policy "photos_insert_all"
  on public.photos for insert
  with check (true);

create policy "photos_delete_all"
  on public.photos for delete
  using (true);

-- Create songs table
create table if not exists public.songs (
  id uuid primary key default gen_random_uuid(),
  author text not null,
  title text not null,
  artist text not null,
  link text,
  note text,
  created_at timestamp with time zone default now()
);

alter table public.songs enable row level security;

create policy "songs_select_all"
  on public.songs for select
  using (true);

create policy "songs_insert_all"
  on public.songs for insert
  with check (true);

create policy "songs_delete_all"
  on public.songs for delete
  using (true);

-- Create surprises table
create table if not exists public.surprises (
  id uuid primary key default gen_random_uuid(),
  author text not null,
  message text not null,
  opened boolean default false,
  opened_at timestamp with time zone,
  created_at timestamp with time zone default now()
);

alter table public.surprises enable row level security;

create policy "surprises_select_all"
  on public.surprises for select
  using (true);

create policy "surprises_insert_all"
  on public.surprises for insert
  with check (true);

create policy "surprises_update_all"
  on public.surprises for update
  using (true);

create policy "surprises_delete_all"
  on public.surprises for delete
  using (true);

-- Create dreams table
create table if not exists public.dreams (
  id uuid primary key default gen_random_uuid(),
  author text not null,
  dream text not null,
  completed boolean default false,
  created_at timestamp with time zone default now()
);

alter table public.dreams enable row level security;

create policy "dreams_select_all"
  on public.dreams for select
  using (true);

create policy "dreams_insert_all"
  on public.dreams for insert
  with check (true);

create policy "dreams_update_all"
  on public.dreams for update
  using (true);

create policy "dreams_delete_all"
  on public.dreams for delete
  using (true);

-- Create storage bucket for photos
insert into storage.buckets (id, name, public)
values ('photos', 'photos', true)
on conflict (id) do nothing;

-- Allow public access to photos bucket
create policy "photos_bucket_select_all"
  on storage.objects for select
  using (bucket_id = 'photos');

create policy "photos_bucket_insert_all"
  on storage.objects for insert
  with check (bucket_id = 'photos');

create policy "photos_bucket_delete_all"
  on storage.objects for delete
  using (bucket_id = 'photos');
